﻿---
name: stock-kline-event-attribution
description: Build or refine Alva playbooks for US stock daily K-line event attribution. Use when the user wants a multi-stock candlestick dashboard, click/brush explanations, source-backed same-day news, one primary gap or move cause, trader-grade interval narratives, three-month breakout reports, evidence filtering, or Chinese investor-facing reports tied to stock chart moves.
---

# Stock K-Line Event Attribution

## Purpose

Build or refine an Alva playbook that explains why US stocks moved on daily K-line/candlestick charts. The playbook should be chart-first: users select a ticker, click a candle, or brush a date range, then receive source-backed news, one primary reason, auxiliary views, and a trader-style narrative in plain Chinese.

Do not build a score dashboard. Prioritize decision-useful explanations over factor rankings, raw percentage-point dumps, or backend-style source wording.

## Product Shape

Create a clean workspace with:

- A large daily K-line/candlestick chart as the main surface.
- Multi-stock selector and filters for ticker, period, chart mode, and event type.
- Click interaction for one candle/day.
- Brush or region selection for a date range.
- A right-side evidence panel for the selected day or range.
- A standalone report area for plain-language conclusions.
- A three-month breakout report, with downside breaks separated into a risk section.

Use Chinese-first investor-facing language. Keep raw IDs, feed names, endpoint names, scheduler details, and internal data mechanics out of visible copy.

## Evidence Rules

Every factual claim must come from live feed output, Alva Data Skills, Platform Data, or a validated source fetched at runtime. Do not hardcode market values, news, prices, dates, or catalysts into HTML.

Use this evidence hierarchy:

1. Original same-day/company news: primary source for daily explanations when it clearly matches the selected ticker/company.
2. Company filings, earnings, guidance, analyst/research-style news: strong company evidence when source-backed.
3. Sector/peer context: allowed only when labeled as sector or peer context and actually relevant.
4. Market/macro context: allowed only when it plausibly explains broad tape and is source-backed.
5. KOL/video/blogger views: auxiliary context only. Do not let opinions override the primary cause unless they point to a verified factual event.
6. Technical/volume evidence: supporting context only. Never fabricate a narrative from chart shape alone.

Ticker-specific company news must match the selected ticker, company name, or source metadata. Do not treat unrelated ETF, small-cap, crypto, structured-note, portfolio-listicle, or “also mentions ticker” items as company evidence.

When evidence is missing, say so plainly in Chinese. Do not fill gaps with plausible-sounding explanations.

## Clicked Candle Explanation

For a clicked candle/day, render these sections:

- **原始同日新闻**: original news items first, with visible title, source, date, and link.
- **主要原因判断**: exactly one primary verdict for the gap or move.
- **盘面解释**: a short plain-language explanation connecting news, tape, sector, and the candle.
- **辅助观点**: KOL/video/blogger or investor views, clearly separated.
- **证据缺口**: what is missing, weak, or uncertain.

For gap days or large moves, do not show “Top 3” causes. Choose one primary reason:

- Direct company news or earnings if present and timing fits.
- Otherwise sector/peer move if the stock moved with a clear group driver.
- Otherwise broad market/macro if most of the move is market-led.
- Otherwise volume/positioning/technical explanation only if no stronger source exists, and state the lower confidence.

Do not present buy/sell/hold advice, price targets, or trading instructions. A trader-style interpretation of what mattered and what to watch is acceptable.

## Range Narrative

For brushed/selected date ranges, write a chronological trader read rather than a metric list. Include:

- **第一段驱动**: what drove the first leg.
- **变化节点**: what changed, with the date or window if source-backed.
- **走势延续/衰退/反转**: whether the move continued, faded, or reversed, and why.
- **专家结论**: one concise expert conclusion.
- **证据来源**: links or named source items that support the story.
- **缺失信息**: important missing source coverage.

Only mention policy, rates, politicians, countries, earnings, or sector themes when the selected range has source-backed evidence. If the user gives examples such as “Trump news”, “Korea semiconductor news”, or “Facebook/META news”, verify them before using them.

## Three-Month Breakout Report

The breakout report must include only constructive upside events:

- New local high or range breakout.
- Gap up with follow-through.
- High-volume upside move.
- Break above important moving average with positive price action.
- Sector/peer-supported upside continuation.

Do not mix selloffs, downside gaps, negative-volume breaks, or moving-average breakdowns into the breakout list. Put those in a separate **下行风险/破位风险** section.

Each breakout entry should explain:

- Breakout date or range.
- What price action changed.
- Market mood at the time.
- What the market was trading or speculating on.
- Relevant company, sector, peer, or news evidence.
- What happened afterward.
- Evidence quality or gaps.

## UI Guidance

Prioritize a clean chart-first workspace:

- Make the chart large enough to inspect candles and selected regions.
- Use ECharts candlestick series with volume and MA20/MA50 when available.
- Add event markers without overcrowding the chart.
- Support click and brush selection. Keep a brushed range visually highlighted.
- Update the report when ticker, range, event type, or selected candle changes.
- Keep metrics secondary. Hide or demote score fields from the main reader path.

Avoid visible copy like “Arrays stock daily kline”, raw field names, percentage-point jargon, feed paths, or scheduler wording. Prefer Chinese labels such as “核心结论”, “同日新闻”, “主要原因”, “区间复盘”, “辅助观点”, and “证据缺口”.

## Alva Workflow

When changing an existing playbook:

1. Verify the current state before editing: `playbook.json`, current HTML, README, feed source, latest feed output, automation state.
2. Read the latest release feed binding and reuse it unless a deliberate contract change is required.
3. Update the feed before the UI if the HTML needs new factual fields.
4. Run the exact stored feed source, not only a local draft.
5. Verify output shape for at least two tickers and two date windows.
6. Lint the playbook.
7. Release only after the core data path, public read, and screenshot render pass.
8. End with the live playbook URL.

Follow Alva references for content legitimacy, feed lifecycle, jagent runtime, operational pitfalls, playbook creation, design, release, search, and Fintwit/KOL surfaces as needed.

## Feed Contract Checklist

Prefer feed fields like:

- `ohlcv_series`
- `events`
- `daily_news_items`
- `primary_gap_reason`
- `primary_move_reason`
- `auxiliary_views`
- `selected_day_explain_zh`
- `trader_interval_read_zh`
- `turning_points`
- `breakout_report_3m`
- `risk_breakdown_3m`
- `source_quality`
- `evidence_gaps`

Keep source items structured with:

- `type`
- `title`
- `source`
- `date`
- `url`
- `relevance_reason`
- `context_label`: company, sector, peer, market, macro, or auxiliary

## Validation Checklist

Before the final response, verify:

- Clicking a candle shows that day’s relevant news first.
- Gap/move cards show one primary reason, not ranked causes.
- KOL/video/blogger views are separated as auxiliary.
- Brushed ranges produce a chronological story.
- Breakout report contains only upside/constructive breakouts.
- Downside breaks appear in risk, not breakout.
- No unrelated news is treated as company evidence.
- Reader-facing Chinese does not leak backend wording.
- Missing evidence is explicitly labeled.
- Screenshot confirms the chart, click panel, range report, and breakout report render.

## Final Response

Summarize what changed in user-facing terms:

- chart behavior
- same-day news
- primary cause logic
- interval narrative
- breakout/risk report
- verification performed

End with the live URL when released.
